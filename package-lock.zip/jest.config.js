module.exports = {
  setupFiles: ['<rootDir>/app/test-utils/setup.js']
};
