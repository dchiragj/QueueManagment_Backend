// set env variables from the local .env.test file
require('../config/env');
